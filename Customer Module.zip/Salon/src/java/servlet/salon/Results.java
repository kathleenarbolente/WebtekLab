/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet.salon;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import servlet.beans.ServiceProvider;

/**
 *
 * @author Aeneid Adversalo
 */
@WebServlet(name = "Results", urlPatterns = {"/Results"})
public class Results extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html><html lang=\"en\">\n" +
            "<head>\n" +
            "<meta charset=\"utf-8\">\n" +
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
            "<meta name=\"description\" content=\"\">\n" +
            "<meta name=\"author\" content=\"\">\n" +
            "<title>Feel Good,Look Good - Search </title>\n" +
            "<link rel=\"stylesheet\" href=\"https://www.w3schools.com/w3css/4/w3.css\">\n" +
            "<!-- Bootstrap Core CSS -->\n" +
            "<link rel=\"stylesheet\" href=\"css/bootstrap.min.css\" type=\"text/css\">\n" +
            "<!-- Custom Fonts -->\n" +
            "<link href='https://fonts.googleapis.com/css?family=Mrs+Sheppards%7CDosis:300,400,700%7COpen+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800;' rel='stylesheet' type='text/css'>\n" +
            "<link rel=\"stylesheet\" href=\"font-awesome/css/font-awesome.min.css\" type=\"text/css\">\n" +
            "<!-- Plugin CSS -->\n" +
            "<link rel=\"stylesheet\" href=\"css/animate.min.css\" type=\"text/css\">\n" +
            "<!-- Custom CSS -->\n" +
            "<link rel=\"stylesheet\" href=\"css/style.css\" type=\"text/css\">\n" +
            "<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->\n" +
            "<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->\n" +
            "<!--[if lt IE 9]>\n" +
            "        <script src=\"https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js\"></script>\n" +
            "        <script src=\"https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js\"></script>\n" +
            "    <![endif]-->\n" +
            "    <link rel=\"shortcut icon\" type=\"image/png\" href=\"img\\demo\\logo.png\">\n" +
            "    \n" +
            "</head>\n" +
            "<body id=\"page-top\">\n" +
            "<nav id=\"mainNav\" class=\"navbar navbar-default navbar-fixed-top\">\n" +
            "<div class=\"container\">\n" +
            "	<!-- Brand and toggle get grouped for better mobile display -->\n" +
            "	<div class=\"navbar-header\">\n" +
            "		<button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\">\n" +
            "		<span class=\"sr-only\">Toggle navigation</span>\n" +
            "		<span class=\"icon-bar\"></span>\n" +
            "		<span class=\"icon-bar\"></span>\n" +
            "		<span class=\"icon-bar\"></span>\n" +
            "		</button>\n" +
            "		<a class=\"navbar-brand page-scroll\" href=\"#page-top\"><img src=\"\" alt=\"\"></a>\n" +
            "	</div>\n" +
            "    \n" +
            "	<!-- Collect the nav links, forms, and other content for toggling -->\n" +
            "	<div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">\n" +
            "		<ul class=\"nav navbar-nav navbar-right\">\n" +
            "			<li>\n" +
            "			<a class=\"page-scroll\" href=\"#page-top\">Home</a>\n" +
            "			</li>\n" +
            "			<li>\n" +
            "			<a class=\"page-scroll\" href=\"#services\">Services</a>\n" +
            "			</li>\n" +
            "			<li>\n" +
            "			<a class=\"page-scroll\" href=\"#about\">About</a>\n" +
            "			</li>\n" +
            "			<li>\n" +
            "			<a class=\"page-scroll\" href=\"#contact\">Booking</a>\n" +
            "			</li>\n" +
            "            <li>\n" +
            "			<a class=\"page-scroll\" href=\"profile.html\">My Profile</a>\n" +
            "			</li>\n" +
            "             <li>\n" +
            "                <div class=\"dropdown\">\n" +
            "                      <a id=\"dLabel\" role=\"button\" data-toggle=\"dropdown\" data-target=\"#\" href=\"/page.html\">\n" +
            "                        <i class=\"glyphicon glyphicon-bell\"></i>\n" +
            "                      </a>\n" +
            "                      <ul class=\"dropdown-menu notifications\" role=\"menu\" aria-labelledby=\"dLabel\">\n" +
            "\n" +
            "                        <div class=\"notification-heading\"><h4 class=\"menu-title\">Notifications</h4><h4 class=\"menu-title pull-right\">View all<i class=\"glyphicon glyphicon-circle-arrow-right\"></i></h4>\n" +
            "                        </div>\n" +
            "                        <li class=\"divider\"></li>\n" +
            "                       <div class=\"notifications-wrapper\">\n" +
            "                         <a class=\"content\" href=\"#\">\n" +
            "\n" +
            "                           <div class=\"notification-item\">\n" +
            "                            <h4 class=\"item-title\">Evaluation Deadline 1 Â· day ago</h4>\n" +
            "                            <p class=\"item-info\">Marketing 101, Video Assignment</p>\n" +
            "                          </div>\n" +
            "\n" +
            "                        </a>\n" +
            "                         <a class=\"content\" href=\"#\">\n" +
            "                          <div class=\"notification-item\">\n" +
            "                            <h4 class=\"item-title\">Evaluation Deadline 1 Â· day ago</h4>\n" +
            "                            <p class=\"item-info\">Marketing 101, Video Assignment</p>\n" +
            "                          </div>\n" +
            "                        </a>\n" +
            "                         <a class=\"content\" href=\"#\">\n" +
            "                          <div class=\"notification-item\">\n" +
            "                            <h4 class=\"item-title\">Evaluation Deadline 1 â¢ day ago</h4>\n" +
            "                            <p class=\"item-info\">Marketing 101, Video Assignment</p>\n" +
            "                          </div>\n" +
            "                        </a>\n" +
            "                         <a class=\"content\" href=\"#\">\n" +
            "                          <div class=\"notification-item\">\n" +
            "                            <h4 class=\"item-title\">Evaluation Deadline 1 â¢ day ago</h4>\n" +
            "                            <p class=\"item-info\">Marketing 101, Video Assignment</p>\n" +
            "                          </div>\n" +
            "\n" +
            "                        </a>\n" +
            "                         <a class=\"content\" href=\"#\">\n" +
            "                          <div class=\"notification-item\">\n" +
            "                            <h4 class=\"item-title\">Evaluation Deadline 1 â¢ day ago</h4>\n" +
            "                            <p class=\"item-info\">Marketing 101, Video Assignment</p>\n" +
            "                          </div>\n" +
            "                        </a>\n" +
            "                         <a class=\"content\" href=\"#\">\n" +
            "                          <div class=\"notification-item\">\n" +
            "                            <h4 class=\"item-title\">Evaluation Deadline 1 â¢ day ago</h4>\n" +
            "                            <p class=\"item-info\">Marketing 101, Video Assignment</p>\n" +
            "                          </div>\n" +
            "                        </a>\n" +
            "\n" +
            "                       </div>\n" +
            "                        <li class=\"divider\"></li>\n" +
            "                        <div class=\"notification-footer\"><h4 class=\"menu-title\">View all<i class=\"glyphicon glyphicon-circle-arrow-right\"></i></h4></div>\n" +
            "                      </ul>\n" +
            "\n" +
            "                    </div>\n" +
            "                  </a>\n" +
            "                            </li>\n" +
            "                        </ul>\n" +
            "                    </div>\n" +
            "                    <!-- /.navbar-collapse -->\n" +
            "                </div>\n" +
            "                <!-- /.container -->\n" +
            "                </nav>");
            ArrayList<ServiceProvider> spList = new ArrayList<>();
            String search = request.getParameter("search");
            try{
                Class.forName("com.mysql.jdbc.Driver");
                String url="jdbc:mysql://localhost:3306/salon";
                String username="root";
                String password="";
                PreparedStatement ps;
                String query="SELECT serv_id, first_name, last_name FROM service_provider WHERE serviceOffer LIKE ?";
                Connection conn = DriverManager.getConnection(url);
                Statement st = conn.createStatement();
                ps = conn.prepareStatement(query);
                ps.setString(1, search + "%");
                ResultSet rs = ps.executeQuery();

                if (rs.first()) {
                do {
                    ServiceProvider sp = new ServiceProvider(
                            rs.getInt("serv_id"),
                            rs.getString("first_name"),
                            rs.getString("last_name"));

                    spList.add(sp);
                } while (rs.next());
            }

                out.printf("<h1>Service Providers for %s </h1>", search);
                out.println("<table><thead><tr><th>Service ID</th><th>First Name</th><th>Last Name</th><th>Image</th></tr></thead>");
                out.println("<tbody>");                
                for (ServiceProvider sp : spList)
                {
                    out.printf("<tr><td>%d</td><td>%s</td><td>%s</td><td></td></tr>", sp.getId(), sp.getfName(), sp.getlName());
                }
                rs.close();
                st.close();
                conn.close();
                out.println("</tbody></table></body>\n" +
"</html>");
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
