/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet.beans;

/**
 *
 * @author Aeneid Adversalo
 */
public class ServiceProvider {
    private int serv_id;
    private String fName;
    private String lName;

    public ServiceProvider(int service_id, String fName, String lName) {
        setId(service_id);
        setfName(fName);
        setlName(lName);
    }
    
    public int getId() {
        return this.serv_id;
    }

    public void setId(int service_id) {
        this.serv_id = service_id;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String desc) {
        this.fName = desc;
    }
    
    public String getlName() {
        return lName;
    }

    public void setlName(String desc) {
        this.lName = desc;
    }

}
    
